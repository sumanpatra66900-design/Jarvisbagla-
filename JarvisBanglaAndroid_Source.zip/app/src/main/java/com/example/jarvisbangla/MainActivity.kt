package com.example.jarvisbangla

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(7, 12, 27)
    private val panel = Color.rgb(17, 27, 49)
    private val cyan = Color.rgb(62, 215, 255)
    private val white = Color.rgb(238, 245, 255)
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()
    private lateinit var apiKeyInput: EditText
    private lateinit var chatBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var micButton: Button
    private lateinit var sendButton: Button
    private lateinit var questionInput: EditText
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        buildUi()
        requestMicPermission()
        addMessage("assistant", "নমস্কার! আমি তোমার Jarvis। নিচে Gemini API key যোগ করো, তারপর বাংলায় কথা বলো বা লিখে প্রশ্ন করো।")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(10))
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 25f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        root.addView(title, lp(-1, dp(42)))

        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT  •  বাংলা"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, lp(-1, dp(24)))

        apiKeyInput = EditText(this).apply {
            hint = "Gemini API key (এই সেশনে ব্যবহৃত হবে)"
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            inputType = 129 // textPassword
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(panel)
        }
        root.addView(apiKeyInput, lp(-1, dp(48)).apply { topMargin = dp(10) })

        status = TextView(this).apply {
            text = "Ready • API key যোগ করো"
            textSize = 12f
            setTextColor(cyan)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(status, lp(-1, dp(30)))

        scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(panel)
        }
        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        scroll.addView(chatBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(6); bottomMargin = dp(10)
        })

        questionInput = EditText(this).apply {
            hint = "এখানে লিখে প্রশ্ন করো…"
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 16f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
            minLines = 1
            maxLines = 3
        }
        root.addView(questionInput, lp(-1, dp(52)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        micButton = Button(this).apply {
            text = "🎙 কথা বলো"
            setTextColor(bg)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan))
            setOnClickListener { toggleListening() }
        }
        sendButton = Button(this).apply {
            text = "পাঠাও ➤"
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 88, 130)))
            setOnClickListener {
                val q = questionInput.text.toString().trim()
                if (q.isNotEmpty()) {
                    questionInput.setText("")
                    hideKeyboard()
                    askJarvis(q)
                }
            }
        }
        buttons.addView(micButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(5) })
        buttons.addView(sendButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(5) })
        root.addView(buttons, lp(-1, dp(58)))
        setContentView(root)
    }

    private fun askJarvis(question: String) {
        if (busy) {
            addMessage("assistant", "একটু অপেক্ষা করো, আমি আগের প্রশ্নের উত্তর তৈরি করছি।")
            return
        }
        val key = apiKeyInput.text.toString().trim()
        if (key.isBlank()) {
            addMessage("assistant", "প্রথমে Google AI Studio থেকে Gemini API key তৈরি করে উপরের ঘরে বসাও।")
            status.text = "API key দরকার"
            return
        }
        addMessage("user", question)
        history.add("user" to question)
        busy = true
        status.text = "ভাবছি…"
        micButton.isEnabled = false
        executor.execute {
            try {
                val answer = callGemini(key)
                history.add("assistant" to answer)
                while (history.size > 16) history.removeAt(0)
                main.post {
                    addMessage("assistant", answer)
                    status.text = "Ready • উত্তর তৈরি হয়েছে"
                    busy = false
                    micButton.isEnabled = true
                    speak(answer)
                }
            } catch (e: Exception) {
                main.post {
                    addMessage("assistant", "সংযোগে সমস্যা হয়েছে: ${e.message ?: "আবার চেষ্টা করো"}")
                    status.text = "Connection error"
                    busy = false
                    micButton.isEnabled = true
                }
            }
        }
    }

    private fun callGemini(key: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        val contents = JSONArray()
        synchronized(history) {
            history.takeLast(16).forEach { (role, text) ->
                contents.put(JSONObject()
                    .put("role", if (role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put(
                "text",
                "তুমি Jarvis নামের একজন সহায়ক AI। ব্যবহারকারীর সঙ্গে স্বাভাবিক, ভদ্র, উষ্ণ বাংলায় কথা বলবে। ব্যবহারকারী অন্য ভাষা চাইলে সেই ভাষায় উত্তর দেবে। উত্তর সংক্ষিপ্ত, পরিষ্কার ও সহায়ক রাখবে। তুমি নিজেকে বাস্তব মানুষ বলে দাবি করবে না। ফোনে কোনো কাজ করে ফেলেছ বলে দাবি করবে না, যদি অ্যাপটি তা বাস্তবে না করে থাকে।"
            ))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        val json = JSONObject(response)
        if (code !in 200..299) {
            val message = json.optJSONObject("error")?.optString("message") ?: "HTTP $code"
            throw Exception(message.take(180))
        }
        return json.optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")
            ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            ?.takeIf { it.isNotBlank() } ?: "দুঃখিত, এবার উত্তর তৈরি করতে পারলাম না। আবার বলবে?"
    }

    private fun toggleListening() {
        if (busy) return
        if (listening) {
            speechRecognizer?.stopListening()
            listening = false
            micButton.text = "🎙 কথা বলো"
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("assistant", "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না। Google app/Speech Services আপডেট করে দেখো, অথবা নিচে লিখে প্রশ্ন করো।")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            return
        }
        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { main.post { status.text = "শুনছি… বাংলায় বলো" } }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { main.post { listening = false; micButton.text = "🎙 কথা বলো" } }
                    override fun onError(error: Int) {
                        main.post {
                            listening = false
                            micButton.text = "🎙 কথা বলো"
                            status.text = "আবার চেষ্টা করো"
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        main.post {
                            if (!spoken.isNullOrBlank()) askJarvis(spoken)
                            else status.text = "কথা বুঝতে পারিনি"
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলো")
            }
            listening = true
            micButton.text = "⏹ থামাও"
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            listening = false
            micButton.text = "🎙 কথা বলো"
            addMessage("assistant", "মাইক্রোফোন চালু করা যায়নি। Permission চেক করো।")
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        // Bengali voice availability varies by phone. Use Bengali if supported.
        val result = tts?.setLanguage(Locale.forLanguageTag("bn-IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            status.text = "বাংলা TTS নেই—ফোনের Text-to-Speech সেটিংসে Bengali voice ইনস্টল করো"
            return
        }
        tts?.setSpeechRate(0.94f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale.forLanguageTag("bn-IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                main.post { status.text = "বাংলা voice ইনস্টল করতে হবে" }
            }
        }
    }

    private fun addMessage(role: String, message: String) {
        val bubble = TextView(this).apply {
            text = (if (role == "user") "তুমি\n" else "JARVIS\n") + message
            textSize = 15f
            setTextColor(if (role == "user") cyan else white)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(if (role == "user") Color.rgb(22, 49, 70) else Color.rgb(24, 36, 59))
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        }
        chatBox.addView(bubble, params)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun requestMicPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(questionInput.windowToken, 0)
        } catch (_: Exception) {}
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
