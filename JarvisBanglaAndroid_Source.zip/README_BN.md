# Jarvis Bangla — Android starter project

এটি একটি প্রাথমিক Android voice-assistant প্রজেক্ট:
- Android SpeechRecognizer দিয়ে বাংলা voice input (ফোন/Google speech service-এর ওপর নির্ভরশীল)
- Gemini API দিয়ে অনলাইন উত্তর
- Android TextToSpeech দিয়ে বাংলা উত্তর শোনানোর চেষ্টা
- বর্তমান অ্যাপ সেশনে সাম্প্রতিক কথোপকথনের context

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. এটি এখনো সম্পূর্ণ real-time, uninterrupted live voice নয়। ব্যবহারকারী একবার বলবে, speech-to-text হবে, AI উত্তর দেবে, তারপর TTS উত্তর পড়বে।
2. বাংলা female voice সব ফোনে নিশ্চিত নয়। Android Settings → Text-to-speech output-এ Bengali voice থাকলে ইনস্টল/নির্বাচন করো।
3. Gemini API key অ্যাপের input-এ দিলে নেটওয়ার্ক অনুরোধে ব্যবহার হয়; এই starter অ্যাপ key স্থায়ীভাবে সংরক্ষণ করে না। তবুও production app-এ mobile app-এর ভেতরে API key রাখা নিরাপদ নয়। ব্যক্তিগত পরীক্ষার বাইরে ব্যবহার করলে backend/proxy যোগ করো।
4. ফোনের settings/apps নিজে থেকে চালানো এখনো যুক্ত করা নেই। পরের ধাপে নির্দিষ্ট Android intents ও user-confirmed actions যোগ করতে হবে।
5. API ব্যবহার করতে internet লাগবে; Google AI Studio-তে API key এবং account/project-এর প্রয়োজন হতে পারে। ব্যবহার/খরচ/limits Google-এর বর্তমান নীতির ওপর নির্ভরশীল।

## Android ফোন থেকেই APK বানানোর সহজতম বাস্তব পথ
এই source project-এর জন্য AndroidIDE-এর মতো Android development environment ব্যবহার করে Gradle build করা যেতে পারে। অন্য বিকল্প হলো GitHub-এ project আপলোড করে GitHub Actions-এ build চালানো, কিন্তু তার জন্য Gradle wrapper files (`gradlew`, `gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties`) লাগবে।

### Gradle wrapper তৈরি
Gradle 8.9-সহ পরিবেশে project root-এ চালাও:
`gradle wrapper --gradle-version 8.9`

তারপর `gradlew` ও `gradle/wrapper/`-সহ সব project files GitHub-এ আপলোড করো। GitHub Actions-এর Actions tab থেকে `Build Jarvis Bangla APK` চালাও। সফল হলে workflow run-এর Artifacts অংশ থেকে `JarvisBangla-debug-apk` ডাউনলোড করে ZIP extract করে `app-debug.apk` ইনস্টল করো।

### Google AI Studio key
`https://aistudio.google.com/` থেকে API key তৈরি করো। অ্যাপ চালিয়ে উপরের API key field-এ paste করো। API key কাউকে দিও না এবং public GitHub repository-তে commit করো না।

### বাংলা voice সেটিং
Android Settings-এ `Text-to-speech output` খুঁজে Bengali/Bangla voice data পাওয়া গেলে ইনস্টল করো। voice selection device-ভেদে আলাদা হতে পারে।
